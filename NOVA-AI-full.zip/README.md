# NOVA AI – Advanced Personal AI Assistant

Native Android AI assistant with a secure Vercel backend.

| Stage | Focus | Status |
|-------|-------|--------|
| **1** | Android UI + Navigation | ✅ |
| **2** | Secure Vercel backend | ✅ |
| **3** | Real AI streaming | ✅ |
| **4** | Room history + DataStore memory | ✅ |
| **5** | Images + web research | ✅ |
| **6** | Voice STT / TTS | ✅ |
| **7** | Test, optimize, release | ✅ |

---

## Features

- Streaming AI chat (Markdown-friendly)
- Coding help (Kotlin, Python, JS, …)
- Image understanding (vision models)
- Web research with source citations
- On-device speech-to-text & text-to-speech
- Voice conversation mode
- Local chat history (Room) & preferences (DataStore)
- User-controlled memory items
- Dark Material 3 UI

**Security:** AI provider keys live only on the Vercel server. The app only holds your backend URL and a shared app secret.

---

## Project layout

```
NOVA-AI/
├── app/                 # Kotlin + Jetpack Compose Android app
├── backend/             # Next.js + Vercel AI SDK API
├── TESTING.md           # QA checklist
├── RELEASE.md           # Signing & Play Store build
└── README.md
```

---

## Quick start

### Backend

```bash
cd backend
cp .env.example .env.local
# OPENAI_API_KEY=...
# NOVA_API_SECRET=$(openssl rand -hex 32)
npm install && npm run dev
```

### Android

1. Open the `NOVA-AI` folder in Android Studio (JDK 17, SDK 35).
2. Point the app at the backend:

```bash
# Debug against emulator → host machine
./gradlew assembleDebug \
  -PNOVA_BASE_URL=http://10.0.2.2:3000 \
  -PNOVA_API_SECRET=your-secret
```

Or set fallbacks in `ApiConfig.kt`.

3. Run on a device / emulator (API 26+).

### Release

See **[RELEASE.md](RELEASE.md)** for signing and Play Store bundles.  
See **[TESTING.md](TESTING.md)** before shipping.

```bash
./gradlew assembleRelease \
  -PNOVA_BASE_URL=https://your-backend.vercel.app \
  -PNOVA_API_SECRET=your-secret
```

---

## API surface (backend)

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/health` | Health + feature flags |
| GET | `/api/models` | Allowed models |
| POST | `/api/chat` | Streaming / JSON chat (multimodal + optional web search) |
| POST | `/api/research` | Search + optional summary |

---

## License / ownership

You own this project code. Deploy the backend under your Vercel account and keep all provider keys private.

---

## Build APK with GitHub Actions (no Android Studio)

1. Push this repo to GitHub.
2. Open **Actions** → **Build NOVA AI APK** → **Run workflow**.
3. Enter:
   - `base_url` — your Vercel URL (e.g. `https://nova-xxx.vercel.app`)
   - `api_secret` — same value as server `NOVA_API_SECRET`
4. When the run finishes, open the job → **Artifacts** → download **nova-ai-debug-apk**.
5. On your phone: open the ZIP, install `app-debug.apk` (allow install from this source).

Optional: store the secret in the repo under **Settings → Secrets and variables → Actions** as `NOVA_API_SECRET` so you do not type it each time (workflow still accepts a manual override).

> Debug APK is signed with the default Android debug keystore — fine for personal install, not for Play Store.
