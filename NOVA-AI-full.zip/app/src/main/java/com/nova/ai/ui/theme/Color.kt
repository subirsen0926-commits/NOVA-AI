package com.nova.ai.ui.theme

import androidx.compose.ui.graphics.Color

// Brand
val NovaBlue = Color(0xFF4F8CFF)
val NovaPurple = Color(0xFF9B6DFF)
val NovaCyan = Color(0xFF00E5FF)
val NovaDeepBlue = Color(0xFF1A237E)

// Dark theme surfaces
val BackgroundDark = Color(0xFF0A0B14)
val SurfaceDark = Color(0xFF12131F)
val SurfaceVariant = Color(0xFF1C1E2E)
val CardDark = Color(0xFF16182A)

// Text
val TextPrimary = Color(0xFFE8EAFF)
val TextSecondary = Color(0xFFA0A4C0)
val TextMuted = Color(0xFF6B6F8C)

// Bubbles
val UserBubble = Color(0xFF2A2D4A)
val AiBubble = Color(0xFF1A1C2E)

// Status
val Success = Color(0xFF4ADE80)
val Error = Color(0xFFF87171)
val Warning = Color(0xFFFBBF24)

// Gradients
val GradientStart = Color(0xFF4F8CFF)
val GradientEnd = Color(0xFF9B6DFF)
