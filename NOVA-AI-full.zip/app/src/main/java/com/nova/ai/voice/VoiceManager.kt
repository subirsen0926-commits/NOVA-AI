package com.nova.ai.voice

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.content.ContextCompat
import java.util.Locale
import java.util.UUID

/**
 * Device STT + TTS for NOVA AI (Stage 6).
 * Uses Android SpeechRecognizer and TextToSpeech – no cloud voice keys required.
 */
class VoiceManager(private val context: Context) {

    interface Listener {
        fun onListeningStarted() {}
        fun onPartialResult(text: String) {}
        fun onFinalResult(text: String) {}
        fun onListeningEnded() {}
        fun onError(message: String) {}
        fun onSpeakStarted() {}
        fun onSpeakEnded() {}
    }

    var listener: Listener? = null

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    var isListening: Boolean = false
        private set

    @Volatile
    var isSpeaking: Boolean = false
        private set

    fun hasMicPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun isSttAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun initTts(preferredLocale: Locale = Locale.getDefault()) {
        if (tts != null) return
        tts = TextToSpeech(context.applicationContext) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.language = preferredLocale
                // Fallback to US English if locale not supported
                val result = tts?.setLanguage(preferredLocale)
                if (result == TextToSpeech.LANG_MISSING_DATA ||
                    result == TextToSpeech.LANG_NOT_SUPPORTED
                ) {
                    tts?.language = Locale.US
                }
                tts?.setSpeechRate(1.0f)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        isSpeaking = true
                        mainHandler.post { listener?.onSpeakStarted() }
                    }

                    override fun onDone(utteranceId: String?) {
                        isSpeaking = false
                        mainHandler.post { listener?.onSpeakEnded() }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        isSpeaking = false
                        mainHandler.post { listener?.onSpeakEnded() }
                    }
                })
            }
        }
    }

    fun setLanguage(locale: Locale) {
        tts?.language = locale
    }

    fun startListening(languageTag: String? = null) {
        if (!hasMicPermission()) {
            listener?.onError("Microphone permission is required for voice input.")
            return
        }
        if (!isSttAvailable()) {
            listener?.onError("Speech recognition is not available on this device.")
            return
        }
        if (isListening) {
            stopListening()
        }

        // Stop TTS so we don't hear ourselves
        stopSpeaking()

        mainHandler.post {
            try {
                if (speechRecognizer == null) {
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
                    speechRecognizer?.setRecognitionListener(recognitionListener)
                }

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(
                        RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                    )
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    if (!languageTag.isNullOrBlank() && languageTag != "auto") {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
                    } else {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    }
                }

                isListening = true
                listener?.onListeningStarted()
                speechRecognizer?.startListening(intent)
            } catch (e: Exception) {
                isListening = false
                listener?.onError(e.message ?: "Failed to start speech recognition")
            }
        }
    }

    fun stopListening() {
        mainHandler.post {
            try {
                speechRecognizer?.stopListening()
            } catch (_: Exception) {
            }
            isListening = false
            listener?.onListeningEnded()
        }
    }

    fun cancelListening() {
        mainHandler.post {
            try {
                speechRecognizer?.cancel()
            } catch (_: Exception) {
            }
            isListening = false
            listener?.onListeningEnded()
        }
    }

    /**
     * Speak [text]. Strips simple markdown for clearer speech.
     */
    fun speak(text: String) {
        if (!ttsReady || tts == null) {
            initTts()
            // Retry shortly if TTS still initializing
            mainHandler.postDelayed({ speakInternal(text) }, 400)
            return
        }
        speakInternal(text)
    }

    private fun speakInternal(text: String) {
        val cleaned = stripForSpeech(text)
        if (cleaned.isBlank()) return
        val id = UUID.randomUUID().toString()
        tts?.speak(cleaned, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    fun stopSpeaking() {
        tts?.stop()
        isSpeaking = false
    }

    fun shutdown() {
        cancelListening()
        stopSpeaking()
        speechRecognizer?.destroy()
        speechRecognizer = null
        tts?.shutdown()
        tts = null
        ttsReady = false
        listener = null
    }

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {
            isListening = false
            mainHandler.post { listener?.onListeningEnded() }
        }

        override fun onError(error: Int) {
            isListening = false
            val msg = when (error) {
                SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                SpeechRecognizer.ERROR_CLIENT -> "Speech client error"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission denied"
                SpeechRecognizer.ERROR_NETWORK -> "Network error during recognition"
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
                SpeechRecognizer.ERROR_NO_MATCH -> "No speech detected"
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy – try again"
                SpeechRecognizer.ERROR_SERVER -> "Recognition server error"
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech input"
                else -> "Speech recognition error ($error)"
            }
            mainHandler.post {
                listener?.onListeningEnded()
                // Don't surface benign "no match" as hard errors in continuous mode
                if (error != SpeechRecognizer.ERROR_NO_MATCH &&
                    error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                ) {
                    listener?.onError(msg)
                }
            }
        }

        override fun onResults(results: Bundle?) {
            isListening = false
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val text = matches?.firstOrNull().orEmpty()
            mainHandler.post {
                listener?.onListeningEnded()
                if (text.isNotBlank()) {
                    listener?.onFinalResult(text)
                }
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val matches =
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val text = matches?.firstOrNull().orEmpty()
            if (text.isNotBlank()) {
                mainHandler.post { listener?.onPartialResult(text) }
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    companion object {
        /** Remove markdown noise so TTS sounds natural */
        fun stripForSpeech(input: String): String {
            return input
                .replace(Regex("```[\\s\\S]*?```"), " code block omitted. ")
                .replace(Regex("`([^`]+)`"), "$1")
                .replace(Regex("\\*\\*([^*]+)\\*\\*"), "$1")
                .replace(Regex("\\*([^*]+)\\*"), "$1")
                .replace(Regex("#{1,6}\\s*"), "")
                .replace(Regex("\\[([^]]+)]\\([^)]+\\)"), "$1")
                .replace(Regex("https?://\\S+"), " link ")
                .replace(Regex("\\s+"), " ")
                .trim()
        }
    }
}
