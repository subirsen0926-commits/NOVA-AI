package com.nova.ai.ui.screens.chat

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.nova.ai.data.model.MessageRole
import com.nova.ai.data.repository.PreferencesRepository
import com.nova.ai.ui.components.ChatInputBar
import com.nova.ai.ui.components.EmptyState
import com.nova.ai.ui.components.MessageBubble
import com.nova.ai.ui.components.NovaTopBar
import com.nova.ai.ui.theme.Error
import com.nova.ai.ui.theme.NovaBlue
import com.nova.ai.ui.theme.NovaCyan
import com.nova.ai.ui.theme.TextSecondary
import com.nova.ai.viewmodel.ChatViewModel
import com.nova.ai.voice.VoiceManager
import kotlinx.coroutines.flow.collectLatest
import java.util.Locale

@Composable
fun ChatScreen(
    conversationId: String,
    onBack: () -> Unit,
    onOpenSettings: () -> Unit,
    viewModel: ChatViewModel = viewModel()
) {
    val messages by viewModel.messages.collectAsState()
    val inputText by viewModel.inputText.collectAsState()
    val isSending by viewModel.isSending.collectAsState()
    val error by viewModel.error.collectAsState()
    val pendingImage by viewModel.pendingImageUri.collectAsState()
    val webSearch by viewModel.webSearchEnabled.collectAsState()
    val isListening by viewModel.isListening.collectAsState()
    val listState = rememberLazyListState()
    val context = LocalContext.current

    var voiceMode by remember { mutableStateOf(false) }
    var isSpeaking by remember { mutableStateOf(false) }

    val prefs = remember { PreferencesRepository.getInstance(context) }
    val ttsEnabled by prefs.ttsEnabled.collectAsState(initial = true)
    val voiceModePref by prefs.voiceConversationMode.collectAsState(initial = false)
    val language by prefs.language.collectAsState(initial = "auto")

    val voiceManager = remember {
        VoiceManager(context.applicationContext).also { it.initTts() }
    }

    DisposableEffect(Unit) {
        voiceManager.listener = object : VoiceManager.Listener {
            override fun onListeningStarted() {
                viewModel.setListening(true)
            }

            override fun onPartialResult(text: String) {
                viewModel.onInputChange(text)
            }

            override fun onFinalResult(text: String) {
                viewModel.setListening(false)
                val autoSend = voiceMode || voiceModePref
                viewModel.onVoiceResult(text, autoSend = autoSend)
            }

            override fun onListeningEnded() {
                viewModel.setListening(false)
            }

            override fun onError(message: String) {
                viewModel.setListening(false)
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
            }

            override fun onSpeakStarted() {
                isSpeaking = true
            }

            override fun onSpeakEnded() {
                isSpeaking = false
                viewModel.onSpeakFinished()
            }
        }
        onDispose {
            voiceManager.shutdown()
        }
    }

    // Speak when ViewModel requests TTS
    LaunchedEffect(Unit) {
        viewModel.speakRequest.collectLatest { text ->
            if (ttsEnabled || voiceMode || voiceModePref) {
                voiceManager.speak(text)
            }
        }
    }

    // Continuous listening in voice conversation mode
    LaunchedEffect(Unit) {
        viewModel.requestListen.collectLatest {
            if (voiceMode || voiceModePref) {
                startVoiceInput(
                    context = context,
                    voiceManager = voiceManager,
                    language = language,
                    onNeedPermission = { }
                )
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startVoiceInput(context, voiceManager, language) {}
        } else {
            Toast.makeText(context, "Microphone permission is required", Toast.LENGTH_SHORT).show()
        }
    }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) viewModel.setPendingImage(uri)
    }

    LaunchedEffect(conversationId) {
        viewModel.loadConversation(conversationId)
    }

    LaunchedEffect(messages.size, messages.lastOrNull()?.content?.length) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    // Sync language to TTS
    LaunchedEffect(language) {
        val locale = when (language) {
            "hi" -> Locale("hi", "IN")
            "bn" -> Locale("bn", "IN")
            "en" -> Locale.US
            else -> Locale.getDefault()
        }
        voiceManager.setLanguage(locale)
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            NovaTopBar(
                title = "NOVA AI",
                onBack = {
                    voiceManager.stopSpeaking()
                    voiceManager.cancelListening()
                    onBack()
                },
                onSettings = onOpenSettings
            )
        },
        bottomBar = {
            Column {
                if (error != null) {
                    ErrorBanner(message = error ?: "", onDismiss = viewModel::clearError)
                }

                if (isListening) {
                    ListeningIndicator()
                }

                if (pendingImage != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = pendingImage,
                            contentDescription = "Selected image",
                            modifier = Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .border(1.dp, NovaBlue.copy(0.4f), RoundedCornerShape(12.dp)),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Image attached",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = viewModel::clearPendingImage) {
                            Icon(Icons.Default.Close, "Remove image", tint = TextSecondary)
                        }
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = webSearch,
                        onClick = { viewModel.setWebSearchEnabled(!webSearch) },
                        label = { Text("Web research") },
                        leadingIcon = {
                            Icon(Icons.Default.Public, null, modifier = Modifier.size(16.dp))
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NovaBlue.copy(alpha = 0.25f),
                            selectedLabelColor = NovaBlue,
                            selectedLeadingIconColor = NovaBlue
                        )
                    )
                    FilterChip(
                        selected = voiceMode || voiceModePref,
                        onClick = {
                            val next = !(voiceMode || voiceModePref)
                            voiceMode = next
                            viewModel.setVoiceModeActive(next)
                            if (!next) {
                                voiceManager.cancelListening()
                                voiceManager.stopSpeaking()
                            }
                        },
                        label = { Text("Voice mode") },
                        leadingIcon = {
                            Icon(
                                if (voiceMode || voiceModePref) Icons.Default.Mic else Icons.Default.MicOff,
                                null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NovaCyan.copy(alpha = 0.2f),
                            selectedLabelColor = NovaCyan,
                            selectedLeadingIconColor = NovaCyan
                        )
                    )
                    if (isSpeaking) {
                        Icon(
                            Icons.Default.VolumeUp,
                            contentDescription = "Speaking",
                            tint = NovaBlue,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                ChatInputBar(
                    value = inputText,
                    onValueChange = viewModel::onInputChange,
                    onSend = {
                        voiceManager.stopSpeaking()
                        viewModel.sendMessage()
                    },
                    onAttachImage = {
                        imagePicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onVoice = {
                        if (isListening) {
                            voiceManager.stopListening()
                        } else if (isSpeaking) {
                            voiceManager.stopSpeaking()
                        } else {
                            val granted = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED
                            if (granted) {
                                startVoiceInput(context, voiceManager, language) {}
                            } else {
                                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    },
                    isSending = isSending,
                    modifier = Modifier.imePadding()
                )
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (messages.isEmpty() && !isSending) {
                EmptyState(
                    title = "Start a conversation",
                    subtitle = "Type, attach an image, use the mic, or enable Voice mode for hands-free chat.",
                    modifier = Modifier.align(Alignment.Center)
                )
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(messages, key = { it.id }) { message ->
                        Column {
                            if (message.imageUri != null && message.role == MessageRole.USER) {
                                AsyncImage(
                                    model = Uri.parse(message.imageUri),
                                    contentDescription = "Attached image",
                                    modifier = Modifier
                                        .fillMaxWidth(0.7f)
                                        .height(160.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .align(Alignment.End),
                                    contentScale = ContentScale.Crop
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                            }
                            MessageBubble(
                                content = message.content,
                                isUser = message.role == MessageRole.USER,
                                isStreaming = message.isStreaming,
                                onCopy = if (message.role == MessageRole.ASSISTANT && !message.isStreaming) {
                                    {
                                        val clipboard =
                                            context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(
                                            ClipData.newPlainText("NOVA AI", message.content)
                                        )
                                        Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
                                    }
                                } else null,
                                onShare = if (message.role == MessageRole.ASSISTANT && !message.isStreaming) {
                                    {
                                        val intent = Intent(Intent.ACTION_SEND).apply {
                                            type = "text/plain"
                                            putExtra(Intent.EXTRA_TEXT, message.content)
                                        }
                                        context.startActivity(
                                            Intent.createChooser(intent, "Share response")
                                        )
                                    }
                                } else null,
                                onRegenerate = if (
                                    message.role == MessageRole.ASSISTANT &&
                                    !message.isStreaming &&
                                    message == messages.lastOrNull { it.role == MessageRole.ASSISTANT }
                                ) {
                                    { viewModel.regenerateLast() }
                                } else null
                            )
                        }
                    }
                    item { Spacer(modifier = Modifier.height(8.dp)) }
                }
            }
        }
    }
}

private fun startVoiceInput(
    context: Context,
    voiceManager: VoiceManager,
    language: String,
    onNeedPermission: () -> Unit
) {
    if (!voiceManager.hasMicPermission()) {
        onNeedPermission()
        return
    }
    val tag = when (language) {
        "hi" -> "hi-IN"
        "bn" -> "bn-IN"
        "en" -> "en-US"
        else -> null
    }
    voiceManager.startListening(tag)
}

@Composable
private fun ListeningIndicator() {
    val transition = rememberInfiniteTransition(label = "listen")
    val scale by transition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(12.dp)
                .scale(scale)
                .clip(CircleShape)
                .background(Error)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = "Listening…",
            style = MaterialTheme.typography.bodyMedium,
            color = NovaCyan
        )
    }
}

@Composable
private fun ErrorBanner(message: String, onDismiss: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Error.copy(alpha = 0.15f))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = message,
            style = MaterialTheme.typography.bodySmall,
            color = Error,
            modifier = Modifier.weight(1f)
        )
        IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(Icons.Default.Close, "Dismiss", tint = Error, modifier = Modifier.size(16.dp))
        }
    }
}
