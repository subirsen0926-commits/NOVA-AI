package com.nova.ai.data.model

import java.util.UUID

enum class MessageRole {
    USER,
    ASSISTANT,
    SYSTEM
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: MessageRole,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val imageUri: String? = null,
    val isStreaming: Boolean = false,
    val isError: Boolean = false
)

data class Conversation(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val messages: List<ChatMessage> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val preview: String = ""
)

data class SuggestedPrompt(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val prompt: String,
    val icon: String // Material icon name key
)

object SampleData {
    val suggestedPrompts = listOf(
        SuggestedPrompt(
            title = "Explain Quantum Computing",
            prompt = "Explain quantum computing in simple terms with everyday analogies.",
            icon = "science"
        ),
        SuggestedPrompt(
            title = "Write Kotlin Code",
            prompt = "Write a clean Kotlin function that sorts a list of custom objects by multiple fields.",
            icon = "code"
        ),
        SuggestedPrompt(
            title = "Creative Story",
            prompt = "Write a short sci-fi story about an AI discovering emotions for the first time.",
            icon = "auto_stories"
        ),
        SuggestedPrompt(
            title = "Debug This Error",
            prompt = "Help me debug a common NullPointerException in Android Jetpack Compose.",
            icon = "bug_report"
        ),
        SuggestedPrompt(
            title = "Study Plan",
            prompt = "Create a 30-day study plan to master Android development with Kotlin.",
            icon = "school"
        ),
        SuggestedPrompt(
            title = "Brainstorm Ideas",
            prompt = "Brainstorm 10 innovative features for a next-generation AI assistant app.",
            icon = "lightbulb"
        )
    )
}
