package com.nova.ai.data.remote

import android.content.Context
import com.google.gson.Gson
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import java.io.IOException
import java.util.concurrent.TimeUnit

class NovaApiClient(context: Context) {

    private val appContext = context.applicationContext
    private val gson = Gson()
    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    private val client: OkHttpClient by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = if (com.nova.ai.BuildConfig.DEBUG)
                HttpLoggingInterceptor.Level.BASIC
            else
                HttpLoggingInterceptor.Level.NONE
        }
        OkHttpClient.Builder()
            .connectTimeout(ApiConfig.CONNECT_TIMEOUT_SEC, TimeUnit.SECONDS)
            .readTimeout(ApiConfig.READ_TIMEOUT_SEC, TimeUnit.SECONDS)
            .writeTimeout(ApiConfig.WRITE_TIMEOUT_SEC, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                val original = chain.request()
                val builder = original.newBuilder()
                    .header("Authorization", "Bearer ${ApiConfig.API_SECRET}")
                    .header("X-Client-Id", ClientIdProvider.get(appContext))
                chain.proceed(builder.build())
            }
            .addInterceptor(logging)
            .build()
    }

    fun streamChat(request: ChatApiRequest): Flow<StreamEvent> = flow {
        val bodyJson = gson.toJson(request.copy(stream = true))
        val url = ApiConfig.BASE_URL.trimEnd('/') + ApiConfig.CHAT_PATH + "?format=text"
        val httpRequest = Request.Builder()
            .url(url)
            .post(bodyJson.toRequestBody(jsonMedia))
            .header("Content-Type", "application/json")
            .header("Accept", "text/plain")
            .build()

        val response = client.newCall(httpRequest).execute()

        if (!response.isSuccessful) {
            val errorBody = response.body?.string().orEmpty()
            emit(StreamEvent.Error(parseErrorMessage(errorBody, response.code)))
            response.close()
            return@flow
        }

        val body = response.body
        if (body == null) {
            emit(StreamEvent.Error("Empty response from server"))
            response.close()
            return@flow
        }

        val contentType = response.header("Content-Type").orEmpty()
        val isPlainText = contentType.contains("text/plain")

        try {
            if (isPlainText) {
                val source = body.source()
                val buffer = okio.Buffer()
                while (!source.exhausted()) {
                    source.read(buffer, 256)
                    if (buffer.size > 0) {
                        val chunk = buffer.readUtf8()
                        if (chunk.isNotEmpty()) {
                            emit(StreamEvent.TextDelta(chunk))
                        }
                    }
                }
            } else {
                val reader = body.charStream().buffered()
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    val raw = line ?: continue
                    if (raw.isBlank()) continue
                    parseDataStreamLine(raw)?.let { emit(it) }
                }
            }
            emit(StreamEvent.Done)
        } catch (e: IOException) {
            emit(StreamEvent.Error(e.message ?: "Network error while streaming"))
        } finally {
            response.close()
        }
    }.flowOn(Dispatchers.IO)

    suspend fun chatOnce(request: ChatApiRequest): Result<String> {
        return try {
            val bodyJson = gson.toJson(request.copy(stream = false))
            val httpRequest = Request.Builder()
                .url(ApiConfig.BASE_URL.trimEnd('/') + ApiConfig.CHAT_PATH)
                .post(bodyJson.toRequestBody(jsonMedia))
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .build()

            client.newCall(httpRequest).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return Result.failure(Exception(parseErrorMessage(body, response.code)))
                }
                val parsed = gson.fromJson(body, ChatApiResponse::class.java)
                val content = parsed.content
                if (content.isNullOrBlank()) {
                    Result.failure(Exception(parsed.error ?: "Empty response"))
                } else {
                    Result.success(content)
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun research(query: String, summarize: Boolean = true): Result<ResearchResponse> {
        return try {
            val bodyJson = gson.toJson(
                mapOf(
                    "query" to query,
                    "maxResults" to 5,
                    "summarize" to summarize
                )
            )
            val httpRequest = Request.Builder()
                .url(ApiConfig.BASE_URL.trimEnd('/') + ApiConfig.RESEARCH_PATH)
                .post(bodyJson.toRequestBody(jsonMedia))
                .header("Content-Type", "application/json")
                .build()

            client.newCall(httpRequest).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return Result.failure(Exception(parseErrorMessage(body, response.code)))
                }
                Result.success(gson.fromJson(body, ResearchResponse::class.java))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun healthCheck(): Result<HealthResponse> {
        return try {
            val request = Request.Builder()
                .url(ApiConfig.BASE_URL.trimEnd('/') + ApiConfig.HEALTH_PATH)
                .get()
                .build()
            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return Result.failure(Exception("Health check failed (${response.code})"))
                }
                Result.success(gson.fromJson(body, HealthResponse::class.java))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parseDataStreamLine(raw: String): StreamEvent? {
        val colon = raw.indexOf(':')
        if (colon <= 0) return StreamEvent.TextDelta(raw)
        val type = raw.substring(0, colon)
        val payload = raw.substring(colon + 1)
        return when (type) {
            "0" -> {
                val text = parseJsonString(payload)
                if (text.isNotEmpty()) StreamEvent.TextDelta(text) else null
            }
            "e", "3" -> StreamEvent.Error(parseErrorPayload(payload).ifEmpty { payload })
            else -> null
        }
    }

    private fun parseJsonString(payload: String): String {
        return try {
            val el = JsonParser.parseString(payload)
            if (el.isJsonPrimitive && el.asJsonPrimitive.isString) el.asString
            else payload.trim('"')
        } catch (_: Exception) {
            payload.trim().removeSurrounding("\"")
        }
    }

    private fun parseErrorPayload(payload: String): String {
        return try {
            val obj = JsonParser.parseString(payload).asJsonObject
            obj.get("message")?.asString ?: obj.get("error")?.asString ?: payload
        } catch (_: Exception) {
            payload
        }
    }

    private fun parseErrorMessage(body: String, code: Int): String {
        return try {
            val obj = JsonParser.parseString(body).asJsonObject
            obj.get("error")?.asString ?: obj.get("message")?.asString ?: "Request failed ($code)"
        } catch (_: Exception) {
            when (code) {
                401 -> "Unauthorized. Check API secret in ApiConfig.kt"
                429 -> "Rate limit exceeded. Please wait a moment."
                503 -> "Service not configured on the server."
                else -> "Request failed ($code)"
            }
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: NovaApiClient? = null

        fun getInstance(context: Context): NovaApiClient {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: NovaApiClient(context).also { INSTANCE = it }
            }
        }
    }
}
