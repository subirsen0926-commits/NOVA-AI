package com.nova.ai.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "nova_settings")

class PreferencesRepository private constructor(context: Context) {

    private val dataStore = context.applicationContext.dataStore

    val darkTheme: Flow<Boolean> = dataStore.data.map { prefs ->
        prefs[KEY_DARK_THEME] ?: true
    }

    val language: Flow<String> = dataStore.data.map { prefs ->
        prefs[KEY_LANGUAGE] ?: "auto"
    }

    val memoryEnabled: Flow<Boolean> = dataStore.data.map { prefs ->
        prefs[KEY_MEMORY_ENABLED] ?: true
    }

    val ttsEnabled: Flow<Boolean> = dataStore.data.map { prefs ->
        prefs[KEY_TTS_ENABLED] ?: true
    }

    val voiceConversationMode: Flow<Boolean> = dataStore.data.map { prefs ->
        prefs[KEY_VOICE_MODE] ?: false
    }

    suspend fun setDarkTheme(enabled: Boolean) {
        dataStore.edit { it[KEY_DARK_THEME] = enabled }
    }

    suspend fun setLanguage(code: String) {
        dataStore.edit { it[KEY_LANGUAGE] = code }
    }

    suspend fun setMemoryEnabled(enabled: Boolean) {
        dataStore.edit { it[KEY_MEMORY_ENABLED] = enabled }
    }

    suspend fun setTtsEnabled(enabled: Boolean) {
        dataStore.edit { it[KEY_TTS_ENABLED] = enabled }
    }

    suspend fun setVoiceConversationMode(enabled: Boolean) {
        dataStore.edit { it[KEY_VOICE_MODE] = enabled }
    }

    companion object {
        private val KEY_DARK_THEME = booleanPreferencesKey("dark_theme")
        private val KEY_LANGUAGE = stringPreferencesKey("language")
        private val KEY_MEMORY_ENABLED = booleanPreferencesKey("memory_enabled")
        private val KEY_TTS_ENABLED = booleanPreferencesKey("tts_enabled")
        private val KEY_VOICE_MODE = booleanPreferencesKey("voice_conversation_mode")

        @Volatile
        private var INSTANCE: PreferencesRepository? = null

        fun getInstance(context: Context? = null): PreferencesRepository {
            INSTANCE?.let { return it }
            synchronized(this) {
                INSTANCE?.let { return it }
                requireNotNull(context) {
                    "PreferencesRepository.getInstance(context) must be called once with Application context"
                }
                return PreferencesRepository(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
