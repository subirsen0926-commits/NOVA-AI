package com.nova.ai

import android.app.Application
import com.nova.ai.data.repository.ChatRepository
import com.nova.ai.data.repository.MemoryRepository
import com.nova.ai.data.repository.PreferencesRepository

class NovaApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Eager singleton init with Application context
        ChatRepository.getInstance(this)
        PreferencesRepository.getInstance(this)
        MemoryRepository.getInstance(this)
    }
}
