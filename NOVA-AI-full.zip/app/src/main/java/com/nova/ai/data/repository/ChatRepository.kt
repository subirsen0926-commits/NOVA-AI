package com.nova.ai.data.repository

import android.content.Context
import com.nova.ai.data.db.AppDatabase
import com.nova.ai.data.db.ConversationEntity
import com.nova.ai.data.db.toDomain
import com.nova.ai.data.db.toEntity
import com.nova.ai.data.model.ChatMessage
import com.nova.ai.data.model.Conversation
import com.nova.ai.data.model.MessageRole
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

/**
 * Stage 4 – Room-backed chat history.
 * Conversations and messages persist across app restarts.
 */
class ChatRepository private constructor(context: Context) {

    private val db = AppDatabase.getInstance(context)
    private val conversationDao = db.conversationDao()
    private val messageDao = db.messageDao()

    val conversations: Flow<List<Conversation>> =
        conversationDao.observeAll().map { list ->
            list.map { it.toDomain() }
        }

    suspend fun getConversation(id: String): Conversation? {
        val entity = conversationDao.getById(id) ?: return null
        val messages = messageDao.getForConversation(id).map { it.toDomain() }
        return entity.toDomain(messages)
    }

    suspend fun createConversation(title: String, firstMessage: ChatMessage): String {
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val conversation = ConversationEntity(
            id = id,
            title = title.ifBlank { "New Chat" },
            preview = firstMessage.content.take(80),
            createdAt = now,
            updatedAt = now
        )
        conversationDao.upsert(conversation)
        messageDao.insert(firstMessage.toEntity(id))
        return id
    }

    suspend fun appendMessage(conversationId: String, message: ChatMessage) {
        // Skip ephemeral streaming placeholders with empty content
        if (message.isStreaming && message.content.isBlank()) return

        messageDao.insert(message.copy(isStreaming = false).toEntity(conversationId))

        val existing = conversationDao.getById(conversationId) ?: return
        val newTitle = if (
            existing.title == "New Chat" &&
            message.role == MessageRole.USER &&
            message.content.isNotBlank()
        ) {
            message.content.take(40)
        } else {
            existing.title
        }
        val newPreview = if (message.role == MessageRole.USER) {
            message.content.take(80)
        } else {
            existing.preview
        }
        conversationDao.update(
            existing.copy(
                title = newTitle,
                preview = newPreview,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun deleteConversation(id: String) {
        // CASCADE deletes messages
        conversationDao.deleteById(id)
    }

    suspend fun clearAll() {
        messageDao.deleteAll()
        conversationDao.deleteAll()
    }

    companion object {
        @Volatile
        private var INSTANCE: ChatRepository? = null

        fun getInstance(context: Context? = null): ChatRepository {
            INSTANCE?.let { return it }
            synchronized(this) {
                INSTANCE?.let { return it }
                requireNotNull(context) {
                    "ChatRepository.getInstance(context) must be called once with Application context"
                }
                return ChatRepository(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
