package com.nova.ai.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nova.ai.data.model.SampleData
import com.nova.ai.ui.components.ConversationItem
import com.nova.ai.ui.components.EmptyState
import com.nova.ai.ui.components.GradientButton
import com.nova.ai.ui.components.NovaLogo
import com.nova.ai.ui.components.SuggestedPromptCard
import com.nova.ai.ui.theme.GradientEnd
import com.nova.ai.ui.theme.GradientStart
import com.nova.ai.ui.theme.NovaBlue
import com.nova.ai.ui.theme.TextMuted
import com.nova.ai.ui.theme.TextSecondary
import com.nova.ai.viewmodel.HomeViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    onNewChat: () -> Unit,
    onOpenChat: (String) -> Unit,
    onOpenSettings: () -> Unit,
    onSuggestedPrompt: (String) -> Unit,
    viewModel: HomeViewModel = viewModel()
) {
    val conversations by viewModel.conversations.collectAsState()
    val timeFormatter = SimpleDateFormat("MMM d", Locale.getDefault())

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            // Header
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        NovaLogo(size = 40)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "NOVA AI",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = TextSecondary
                        )
                    }
                }
            }

            // Hero / Greeting
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    GradientStart.copy(alpha = 0.15f),
                                    GradientEnd.copy(alpha = 0.12f)
                                )
                            )
                        )
                        .padding(24.dp)
                ) {
                    Column {
                        Text(
                            text = "Hello, I'm NOVA",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Your advanced personal AI assistant.\nAsk me anything — code, research, study, ideas.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        GradientButton(
                            text = "New Chat",
                            onClick = onNewChat,
                            icon = Icons.Default.Add,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // Suggested prompts
            item {
                Text(
                    text = "Suggested",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(start = 20.dp, top = 24.dp, bottom = 12.dp)
                )
            }

            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(SampleData.suggestedPrompts) { prompt ->
                        SuggestedPromptCard(
                            title = prompt.title,
                            onClick = { onSuggestedPrompt(prompt.prompt) },
                            modifier = Modifier.width(220.dp)
                        )
                    }
                }
            }

            // Recent conversations
            item {
                Text(
                    text = "Recent Conversations",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(start = 20.dp, top = 28.dp, bottom = 12.dp)
                )
            }

            if (conversations.isEmpty()) {
                item {
                    EmptyState(
                        title = "No conversations yet",
                        subtitle = "Start a new chat to begin talking with NOVA",
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                }
            } else {
                items(conversations, key = { it.id }) { conversation ->
                    ConversationItem(
                        title = conversation.title,
                        preview = conversation.preview.ifEmpty { "No messages yet" },
                        timeLabel = timeFormatter.format(Date(conversation.updatedAt)),
                        onClick = { onOpenChat(conversation.id) },
                        onDelete = { viewModel.deleteConversation(conversation.id) },
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}
