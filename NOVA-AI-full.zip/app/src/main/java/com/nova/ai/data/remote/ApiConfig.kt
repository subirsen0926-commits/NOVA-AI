package com.nova.ai.data.remote

import com.nova.ai.BuildConfig

/**
 * Backend configuration for NOVA AI.
 *
 * Priority:
 * 1. BuildConfig values (set via Gradle -PNOVA_BASE_URL / -PNOVA_API_SECRET)
 * 2. Fallback constants below for local debug edits
 *
 * Never put OPENAI / Tavily / Serper keys in the Android app.
 */
object ApiConfig {

    /**
     * Examples:
     *   "https://nova-ai-backend-xxxx.vercel.app"
     *   "http://10.0.2.2:3000"  // emulator → host localhost
     */
    private const val FALLBACK_BASE_URL = "https://YOUR_VERCEL_PROJECT.vercel.app"
    private const val FALLBACK_API_SECRET = "change-me-to-match-server-secret"

    val BASE_URL: String
        get() {
            val fromBuild = BuildConfig.NOVA_BASE_URL
            return if (fromBuild.isNotBlank() && !fromBuild.contains("YOUR_VERCEL_PROJECT")) {
                fromBuild
            } else {
                FALLBACK_BASE_URL
            }
        }

    val API_SECRET: String
        get() {
            val fromBuild = BuildConfig.NOVA_API_SECRET
            return if (fromBuild.isNotBlank() && fromBuild != "change-me-to-match-server-secret") {
                fromBuild
            } else {
                FALLBACK_API_SECRET
            }
        }

    const val CHAT_PATH = "/api/chat"
    const val HEALTH_PATH = "/api/health"
    const val MODELS_PATH = "/api/models"
    const val RESEARCH_PATH = "/api/research"

    const val CONNECT_TIMEOUT_SEC = 30L
    const val READ_TIMEOUT_SEC = 120L
    const val WRITE_TIMEOUT_SEC = 30L

    const val IMAGE_MAX_SIDE_PX = 1280
    const val IMAGE_JPEG_QUALITY = 82
}
