package com.nova.ai.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nova.ai.data.db.MemoryItem
import com.nova.ai.data.repository.ChatRepository
import com.nova.ai.data.repository.MemoryRepository
import com.nova.ai.data.repository.PreferencesRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val preferences = PreferencesRepository.getInstance(application)
    private val chatRepository = ChatRepository.getInstance(application)
    private val memoryRepository = MemoryRepository.getInstance(application)

    val darkTheme: StateFlow<Boolean> = preferences.darkTheme
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val language: StateFlow<String> = preferences.language
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "auto")

    val memoryEnabled: StateFlow<Boolean> = preferences.memoryEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val ttsEnabled: StateFlow<Boolean> = preferences.ttsEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val voiceConversationMode: StateFlow<Boolean> = preferences.voiceConversationMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val memoryItems: StateFlow<List<MemoryItem>> = memoryRepository.items
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setDarkTheme(enabled: Boolean) {
        viewModelScope.launch { preferences.setDarkTheme(enabled) }
    }

    fun setLanguage(code: String) {
        viewModelScope.launch { preferences.setLanguage(code) }
    }

    fun setMemoryEnabled(enabled: Boolean) {
        viewModelScope.launch { preferences.setMemoryEnabled(enabled) }
    }

    fun setTtsEnabled(enabled: Boolean) {
        viewModelScope.launch { preferences.setTtsEnabled(enabled) }
    }

    fun setVoiceConversationMode(enabled: Boolean) {
        viewModelScope.launch { preferences.setVoiceConversationMode(enabled) }
    }

    fun addMemory(key: String, value: String) {
        if (key.isBlank() || value.isBlank()) return
        viewModelScope.launch { memoryRepository.save(key, value) }
    }

    fun deleteMemory(id: String) {
        viewModelScope.launch { memoryRepository.delete(id) }
    }

    fun clearAllMemory() {
        viewModelScope.launch { memoryRepository.clearAll() }
    }

    fun clearAllHistory() {
        viewModelScope.launch { chatRepository.clearAll() }
    }
}
