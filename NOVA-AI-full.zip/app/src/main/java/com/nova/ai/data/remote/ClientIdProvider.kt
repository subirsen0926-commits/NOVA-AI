package com.nova.ai.data.remote

import android.content.Context
import java.util.UUID

/**
 * Stable install-scoped client ID used for rate limiting on the backend.
 * Persisted in SharedPreferences so the same device keeps the same ID.
 */
object ClientIdProvider {
    private const val PREFS = "nova_ai_prefs"
    private const val KEY_CLIENT_ID = "client_id"

    @Volatile
    private var cached: String? = null

    fun get(context: Context): String {
        cached?.let { return it }
        synchronized(this) {
            cached?.let { return it }
            val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val existing = prefs.getString(KEY_CLIENT_ID, null)
            if (existing != null) {
                cached = existing
                return existing
            }
            val id = UUID.randomUUID().toString()
            prefs.edit().putString(KEY_CLIENT_ID, id).apply()
            cached = id
            return id
        }
    }
}
