package com.nova.ai.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.nova.ai.ui.screens.chat.ChatScreen
import com.nova.ai.ui.screens.home.HomeScreen
import com.nova.ai.ui.screens.settings.SettingsScreen

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object Chat : Screen("chat/{conversationId}") {
        fun createRoute(conversationId: String = "new") = "chat/$conversationId"
    }
    data object Settings : Screen("settings")
}

@Composable
fun NovaNavGraph(
    navController: NavHostController,
    modifier: Modifier = Modifier
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Home.route,
        modifier = modifier
    ) {
        composable(Screen.Home.route) {
            HomeScreen(
                onNewChat = {
                    navController.navigate(Screen.Chat.createRoute("new"))
                },
                onOpenChat = { conversationId ->
                    navController.navigate(Screen.Chat.createRoute(conversationId))
                },
                onOpenSettings = {
                    navController.navigate(Screen.Settings.route)
                },
                onSuggestedPrompt = { prompt ->
                    // Pass prompt via savedStateHandle or argument later; for Stage 1 navigate to new chat
                    navController.navigate(Screen.Chat.createRoute("new")) {
                        // In Stage 4 we will pass the prompt content
                    }
                }
            )
        }

        composable(
            route = Screen.Chat.route,
            arguments = listOf(
                navArgument("conversationId") {
                    type = NavType.StringType
                    defaultValue = "new"
                }
            )
        ) { backStackEntry ->
            val conversationId = backStackEntry.arguments?.getString("conversationId") ?: "new"
            ChatScreen(
                conversationId = conversationId,
                onBack = { navController.popBackStack() },
                onOpenSettings = { navController.navigate(Screen.Settings.route) }
            )
        }

        composable(Screen.Settings.route) {
            SettingsScreen(
                onBack = { navController.popBackStack() }
            )
        }
    }
}
