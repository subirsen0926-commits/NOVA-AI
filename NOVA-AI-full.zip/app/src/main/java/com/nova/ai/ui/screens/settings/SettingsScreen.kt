package com.nova.ai.ui.screens.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nova.ai.data.db.MemoryItem
import com.nova.ai.ui.components.NovaTopBar
import com.nova.ai.ui.theme.NovaBlue
import com.nova.ai.ui.theme.TextMuted
import com.nova.ai.ui.theme.TextSecondary
import com.nova.ai.viewmodel.SettingsViewModel

@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    viewModel: SettingsViewModel = viewModel()
) {
    val darkTheme by viewModel.darkTheme.collectAsState()
    val language by viewModel.language.collectAsState()
    val memoryEnabled by viewModel.memoryEnabled.collectAsState()
    val memoryItems by viewModel.memoryItems.collectAsState()
    val ttsEnabled by viewModel.ttsEnabled.collectAsState()
    val voiceConversationMode by viewModel.voiceConversationMode.collectAsState()

    var showClearHistoryDialog by remember { mutableStateOf(false) }
    var showClearMemoryDialog by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var showAddMemory by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            NovaTopBar(title = "Settings", onBack = onBack)
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            SectionHeader("Appearance")

            SettingsCard {
                SettingsToggleRow(
                    icon = Icons.Default.DarkMode,
                    title = "Dark Theme",
                    subtitle = "Futuristic dark interface (recommended)",
                    checked = darkTheme,
                    onCheckedChange = viewModel::setDarkTheme
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
            SectionHeader("Language")

            SettingsCard {
                LanguageOption("English", "en", language, viewModel::setLanguage)
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                LanguageOption("हिन्दी (Hindi)", "hi", language, viewModel::setLanguage)
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                LanguageOption("বাংলা (Bengali)", "bn", language, viewModel::setLanguage)
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                LanguageOption("Auto-detect", "auto", language, viewModel::setLanguage)
            }

            Spacer(modifier = Modifier.height(20.dp))
            SectionHeader("Voice")

            SettingsCard {
                SettingsToggleRow(
                    icon = Icons.Default.VolumeUp,
                    title = "Speak responses",
                    subtitle = "Read assistant replies aloud with device TTS",
                    checked = ttsEnabled,
                    onCheckedChange = viewModel::setTtsEnabled
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                SettingsToggleRow(
                    icon = Icons.Default.RecordVoiceOver,
                    title = "Voice conversation mode",
                    subtitle = "Auto-listen after each spoken reply (hands-free)",
                    checked = voiceConversationMode,
                    onCheckedChange = viewModel::setVoiceConversationMode
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
            SectionHeader("Memory & Privacy")

            SettingsCard {
                SettingsToggleRow(
                    icon = Icons.Default.Memory,
                    title = "Conversation Memory",
                    subtitle = "Use saved preferences as context in chats",
                    checked = memoryEnabled,
                    onCheckedChange = viewModel::setMemoryEnabled
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                SettingsClickRow(
                    icon = Icons.Default.Add,
                    title = "Add memory item",
                    subtitle = "e.g. Preferred language, coding style, name",
                    onClick = { showAddMemory = true }
                )
            }

            if (memoryItems.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Saved preferences",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
                )
                SettingsCard {
                    memoryItems.forEachIndexed { index, item ->
                        MemoryItemRow(
                            item = item,
                            onDelete = { viewModel.deleteMemory(item.id) }
                        )
                        if (index < memoryItems.lastIndex) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                TextButton(onClick = { showClearMemoryDialog = true }) {
                    Text("Clear all memory", color = MaterialTheme.colorScheme.error)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            SettingsCard {
                SettingsClickRow(
                    icon = Icons.Default.DeleteForever,
                    title = "Clear all chat history",
                    subtitle = "Permanently delete every conversation",
                    onClick = { showClearHistoryDialog = true },
                    destructive = true
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
            SectionHeader("About")

            SettingsCard {
                SettingsClickRow(
                    icon = Icons.Default.Info,
                    title = "About NOVA AI",
                    subtitle = "Version 1.0.0 · Advanced Personal AI Assistant",
                    onClick = { showAbout = true }
                )
            }

            Spacer(modifier = Modifier.height(40.dp))
            Text(
                text = "NOVA AI · History & memory persist locally",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showClearHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showClearHistoryDialog = false },
            title = { Text("Clear all history?") },
            text = { Text("This will permanently delete every conversation. This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.clearAllHistory()
                    showClearHistoryDialog = false
                }) {
                    Text("Clear", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearHistoryDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showClearMemoryDialog) {
        AlertDialog(
            onDismissRequest = { showClearMemoryDialog = false },
            title = { Text("Clear all memory?") },
            text = { Text("All saved preferences will be removed.") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.clearAllMemory()
                    showClearMemoryDialog = false
                }) {
                    Text("Clear", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearMemoryDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showAddMemory) {
        AddMemoryDialog(
            onDismiss = { showAddMemory = false },
            onSave = { key, value ->
                viewModel.addMemory(key, value)
                showAddMemory = false
            }
        )
    }

    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("NOVA AI") },
            text = {
                Column {
                    Text("Advanced Personal AI Assistant")
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Chat history is stored locally with Room. " +
                            "Memory preferences are optional and under your control. " +
                            "AI credentials never leave your Vercel backend.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Version 1.0.0 · Stage 4",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showAbout = false }) {
                    Text("OK")
                }
            }
        )
    }
}

@Composable
private fun AddMemoryDialog(
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var key by remember { mutableStateOf("") }
    var value by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add memory") },
        text = {
            Column {
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it },
                    label = { Text("Label") },
                    placeholder = { Text("e.g. Name, Preferred language") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = value,
                    onValueChange = { value = it },
                    label = { Text("Value") },
                    placeholder = { Text("e.g. Alex, Kotlin") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onSave(key.trim(), value.trim()) },
                enabled = key.isNotBlank() && value.isNotBlank()
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun MemoryItemRow(
    item: MemoryItem,
    onDelete: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = item.key,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = item.value,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
        IconButton(onClick = onDelete) {
            Icon(
                imageVector = Icons.Default.Delete,
                contentDescription = "Delete",
                tint = TextMuted,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        color = NovaBlue,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(bottom = 8.dp, start = 4.dp)
    )
}

@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            content()
        }
    }
}

@Composable
private fun SettingsToggleRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = NovaBlue, modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedTrackColor = NovaBlue)
        )
    }
}

@Composable
private fun SettingsClickRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    destructive: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = if (destructive) MaterialTheme.colorScheme.error else NovaBlue,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                color = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
            )
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        }
        Icon(
            Icons.AutoMirrored.Filled.ArrowForwardIos,
            contentDescription = null,
            tint = TextMuted,
            modifier = Modifier.size(14.dp)
        )
    }
}

@Composable
private fun LanguageOption(
    label: String,
    code: String,
    selected: String,
    onSelect: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect(code) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = selected == code,
            onClick = { onSelect(code) },
            colors = RadioButtonDefaults.colors(selectedColor = NovaBlue)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface)
    }
}
