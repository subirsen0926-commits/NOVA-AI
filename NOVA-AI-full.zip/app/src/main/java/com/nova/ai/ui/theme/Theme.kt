package com.nova.ai.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = NovaBlue,
    onPrimary = Color.White,
    primaryContainer = NovaDeepBlue,
    onPrimaryContainer = TextPrimary,
    secondary = NovaPurple,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF2D1B4E),
    onSecondaryContainer = TextPrimary,
    tertiary = NovaCyan,
    onTertiary = Color.Black,
    background = BackgroundDark,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = TextMuted,
    error = Error,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = NovaBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E4FF),
    onPrimaryContainer = Color(0xFF001A41),
    secondary = NovaPurple,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFEEDCFF),
    onSecondaryContainer = Color(0xFF2B0052),
    tertiary = NovaCyan,
    onTertiary = Color.Black,
    background = Color(0xFFF8F9FF),
    onBackground = Color(0xFF1A1B2E),
    surface = Color.White,
    onSurface = Color(0xFF1A1B2E),
    surfaceVariant = Color(0xFFE8EAF6),
    onSurfaceVariant = Color(0xFF4A4D66),
    outline = Color(0xFF8A8DAB),
    error = Error,
    onError = Color.White
)

@Composable
fun NovaAITheme(
    darkTheme: Boolean = true, // Default to dark futuristic theme
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            window.navigationBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = NovaTypography,
        content = content
    )
}
