package com.nova.ai.data.repository

import android.content.Context
import com.nova.ai.data.db.AppDatabase
import com.nova.ai.data.db.MemoryItem
import com.nova.ai.data.db.MemoryItemEntity
import com.nova.ai.data.db.toDomain
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

/**
 * User-controlled memory preferences stored in Room.
 * Used when memory is enabled – e.g. "User prefers Kotlin", "Name is Alex".
 */
class MemoryRepository private constructor(context: Context) {

    private val memoryDao = AppDatabase.getInstance(context).memoryDao()

    val items: Flow<List<MemoryItem>> =
        memoryDao.observeAll().map { list -> list.map { it.toDomain() } }

    suspend fun getAll(): List<MemoryItem> =
        memoryDao.getAll().map { it.toDomain() }

    suspend fun save(key: String, value: String) {
        val existing = memoryDao.getByKey(key)
        val now = System.currentTimeMillis()
        val entity = if (existing != null) {
            existing.copy(value = value, updatedAt = now)
        } else {
            MemoryItemEntity(
                id = UUID.randomUUID().toString(),
                key = key.trim(),
                value = value.trim(),
                createdAt = now,
                updatedAt = now
            )
        }
        memoryDao.upsert(entity)
    }

    suspend fun delete(id: String) {
        memoryDao.deleteById(id)
    }

    suspend fun deleteByKey(key: String) {
        memoryDao.deleteByKey(key)
    }

    suspend fun clearAll() {
        memoryDao.deleteAll()
    }

    /**
     * Builds a short system-context string from stored memory items
     * to inject into chat when memory is enabled.
     */
    suspend fun buildContextBlock(): String {
        val all = getAll()
        if (all.isEmpty()) return ""
        return buildString {
            appendLine("User preferences / memory (respect these when relevant):")
            all.forEach { appendLine("- ${it.key}: ${it.value}") }
        }.trim()
    }

    companion object {
        @Volatile
        private var INSTANCE: MemoryRepository? = null

        fun getInstance(context: Context? = null): MemoryRepository {
            INSTANCE?.let { return it }
            synchronized(this) {
                INSTANCE?.let { return it }
                requireNotNull(context) {
                    "MemoryRepository.getInstance(context) must be called once with Application context"
                }
                return MemoryRepository(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
