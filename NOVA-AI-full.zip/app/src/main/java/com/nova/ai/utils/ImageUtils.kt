package com.nova.ai.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import com.nova.ai.data.remote.ApiConfig
import java.io.ByteArrayOutputStream

object ImageUtils {

    /**
     * Loads, downscales, and encodes an image URI as a JPEG data URL.
     * Returns null on failure.
     */
    fun uriToDataUrl(context: Context, uri: Uri): String? {
        return try {
            val resolver = context.contentResolver
            val input = resolver.openInputStream(uri) ?: return null
            val original = input.use { BitmapFactory.decodeStream(it) } ?: return null

            val scaled = scaleBitmap(original, ApiConfig.IMAGE_MAX_SIDE_PX)
            if (scaled !== original) {
                original.recycle()
            }

            val baos = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, ApiConfig.IMAGE_JPEG_QUALITY, baos)
            scaled.recycle()

            val bytes = baos.toByteArray()
            val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
            "data:image/jpeg;base64,$b64"
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun scaleBitmap(source: Bitmap, maxSide: Int): Bitmap {
        val w = source.width
        val h = source.height
        val longest = maxOf(w, h)
        if (longest <= maxSide) return source
        val scale = maxSide.toFloat() / longest
        val nw = (w * scale).toInt().coerceAtLeast(1)
        val nh = (h * scale).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(source, nw, nh, true)
    }
}
EOF
