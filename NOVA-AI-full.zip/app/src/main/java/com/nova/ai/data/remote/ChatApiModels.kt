package com.nova.ai.data.remote

import com.google.gson.annotations.SerializedName

/** Multimodal content part for vision models */
data class ContentPart(
    val type: String, // "text" | "image"
    val text: String? = null,
    val image: String? = null // data URL
)

data class ApiChatMessage(
    val role: String,
    /** String for text-only, or List<ContentPart> for multimodal – serialized as JSON */
    val content: Any
)

data class ChatApiRequest(
    val messages: List<ApiChatMessage>,
    val model: String? = null,
    val temperature: Double = 0.7,
    @SerializedName("maxTokens") val maxTokens: Int = 2048,
    val stream: Boolean = true,
    val system: String? = null,
    val enableWebSearch: Boolean = false,
    val searchQuery: String? = null
)

data class ChatApiResponse(
    val id: String? = null,
    val model: String? = null,
    val content: String? = null,
    val error: String? = null,
    val webSearch: Boolean? = null
)

data class ResearchResultItem(
    val title: String? = null,
    val url: String? = null,
    val snippet: String? = null
)

data class ResearchResponse(
    val query: String? = null,
    val provider: String? = null,
    val results: List<ResearchResultItem>? = null,
    val summary: String? = null
)

data class HealthResponse(
    val status: String? = null,
    val service: String? = null,
    val version: String? = null,
    @SerializedName("providerConfigured") val providerConfigured: Boolean? = null,
    @SerializedName("searchConfigured") val searchConfigured: Boolean? = null,
    @SerializedName("defaultModel") val defaultModel: String? = null
)

sealed class StreamEvent {
    data class TextDelta(val text: String) : StreamEvent()
    data class Error(val message: String) : StreamEvent()
    data object Done : StreamEvent()
}
