package com.nova.ai.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nova.ai.data.model.ChatMessage
import com.nova.ai.data.model.MessageRole
import com.nova.ai.data.remote.ApiChatMessage
import com.nova.ai.data.remote.ApiConfig
import com.nova.ai.data.remote.ChatApiRequest
import com.nova.ai.data.remote.ContentPart
import com.nova.ai.data.remote.NovaApiClient
import com.nova.ai.data.remote.StreamEvent
import com.nova.ai.data.repository.ChatRepository
import com.nova.ai.data.repository.MemoryRepository
import com.nova.ai.data.repository.PreferencesRepository
import com.nova.ai.utils.ImageUtils
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.UUID

class ChatViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val repository = ChatRepository.getInstance(application)
    private val memoryRepository = MemoryRepository.getInstance(application)
    private val preferences = PreferencesRepository.getInstance(application)
    private val api = NovaApiClient.getInstance(application)

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _isSending = MutableStateFlow(false)
    val isSending: StateFlow<Boolean> = _isSending.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _pendingImageUri = MutableStateFlow<Uri?>(null)
    val pendingImageUri: StateFlow<Uri?> = _pendingImageUri.asStateFlow()

    private val _webSearchEnabled = MutableStateFlow(false)
    val webSearchEnabled: StateFlow<Boolean> = _webSearchEnabled.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    /** Emits full assistant text when a response finishes – for TTS */
    private val _speakRequest = MutableSharedFlow<String>(extraBufferCapacity = 1)
    val speakRequest: SharedFlow<String> = _speakRequest.asSharedFlow()

    /** Emits when voice mode wants to start listening again after TTS */
    private val _requestListen = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val requestListen: SharedFlow<Unit> = _requestListen.asSharedFlow()

    private var currentConversationId: String = "new"
    private var streamJob: Job? = null
    private var voiceModeActive = false

    fun loadConversation(conversationId: String) {
        currentConversationId = conversationId
        viewModelScope.launch {
            if (conversationId == "new") {
                _messages.value = emptyList()
            } else {
                val conversation = repository.getConversation(conversationId)
                _messages.value = conversation?.messages ?: emptyList()
            }
        }
    }

    fun onInputChange(text: String) {
        _inputText.value = text
    }

    fun clearError() {
        _error.value = null
    }

    fun setPendingImage(uri: Uri?) {
        _pendingImageUri.value = uri
    }

    fun clearPendingImage() {
        _pendingImageUri.value = null
    }

    fun setWebSearchEnabled(enabled: Boolean) {
        _webSearchEnabled.value = enabled
    }

    fun setListening(listening: Boolean) {
        _isListening.value = listening
    }

    /** Called by UI when STT returns final text */
    fun onVoiceResult(text: String, autoSend: Boolean) {
        if (text.isBlank()) return
        _inputText.value = text
        if (autoSend) {
            sendMessage()
        }
    }

    fun setVoiceModeActive(active: Boolean) {
        voiceModeActive = active
    }

    fun sendMessage() {
        val text = _inputText.value.trim()
        val imageUri = _pendingImageUri.value
        if ((text.isEmpty() && imageUri == null) || _isSending.value) return

        if (!isBackendConfigured()) {
            _error.value =
                "Backend not configured. Set BASE_URL and API_SECRET in ApiConfig.kt."
            return
        }

        streamJob?.cancel()
        streamJob = viewModelScope.launch {
            _isSending.value = true
            _error.value = null
            _inputText.value = ""
            _pendingImageUri.value = null

            val useWebSearch = _webSearchEnabled.value
            val dataUrl = imageUri?.let {
                ImageUtils.uriToDataUrl(getApplication(), it)
            }
            if (imageUri != null && dataUrl == null) {
                _error.value = "Could not read the selected image."
                _isSending.value = false
                return@launch
            }

            val displayText = when {
                text.isNotEmpty() -> text
                dataUrl != null -> "[Image attached]"
                else -> text
            }

            val userMessage = ChatMessage(
                role = MessageRole.USER,
                content = displayText,
                imageUri = imageUri?.toString()
            )
            _messages.value = _messages.value + userMessage

            if (currentConversationId == "new") {
                currentConversationId = repository.createConversation(
                    title = displayText.take(40).ifEmpty { "New Chat" },
                    firstMessage = userMessage
                )
            } else {
                repository.appendMessage(currentConversationId, userMessage)
            }

            val assistantId = UUID.randomUUID().toString()
            var streamingMessage = ChatMessage(
                id = assistantId,
                role = MessageRole.ASSISTANT,
                content = "",
                isStreaming = true
            )
            _messages.value = _messages.value + streamingMessage

            val history = buildApiHistory(assistantId, text, dataUrl)

            val memoryOn = preferences.memoryEnabled.first()
            val systemExtra = if (memoryOn) {
                memoryRepository.buildContextBlock().ifBlank { null }
            } else null

            val request = ChatApiRequest(
                messages = history,
                stream = true,
                system = systemExtra,
                enableWebSearch = useWebSearch
            )

            val contentBuilder = StringBuilder()
            var completedOk = false

            api.streamChat(request)
                .catch { e ->
                    emit(StreamEvent.Error(e.message ?: "Network error"))
                }
                .collect { event ->
                    when (event) {
                        is StreamEvent.TextDelta -> {
                            contentBuilder.append(event.text)
                            streamingMessage = streamingMessage.copy(
                                content = contentBuilder.toString(),
                                isStreaming = true
                            )
                            updateAssistant(assistantId, streamingMessage)
                        }
                        is StreamEvent.Error -> {
                            val errText = if (contentBuilder.isEmpty()) {
                                "⚠️ ${event.message}"
                            } else {
                                contentBuilder.toString() + "\n\n⚠️ ${event.message}"
                            }
                            streamingMessage = streamingMessage.copy(
                                content = errText,
                                isStreaming = false,
                                isError = true
                            )
                            updateAssistant(assistantId, streamingMessage)
                            repository.appendMessage(currentConversationId, streamingMessage)
                            _error.value = event.message
                        }
                        is StreamEvent.Done -> {
                            if (contentBuilder.isEmpty() && !streamingMessage.isError) {
                                streamingMessage = streamingMessage.copy(
                                    content = "No response received from the model.",
                                    isStreaming = false,
                                    isError = true
                                )
                            } else {
                                streamingMessage = streamingMessage.copy(
                                    content = contentBuilder.toString()
                                        .ifEmpty { streamingMessage.content },
                                    isStreaming = false
                                )
                                completedOk = !streamingMessage.isError &&
                                    streamingMessage.content.isNotBlank()
                            }
                            updateAssistant(assistantId, streamingMessage)
                            if (!streamingMessage.isError && streamingMessage.content.isNotBlank()) {
                                repository.appendMessage(currentConversationId, streamingMessage)
                            }
                        }
                    }
                }

            _isSending.value = false

            if (completedOk) {
                val ttsOn = preferences.ttsEnabled.first()
                val voiceMode = preferences.voiceConversationMode.first() || voiceModeActive
                if (ttsOn || voiceMode) {
                    _speakRequest.emit(streamingMessage.content)
                }
            }
        }
    }

    fun onSpeakFinished() {
        viewModelScope.launch {
            val voiceMode = preferences.voiceConversationMode.first() || voiceModeActive
            if (voiceMode && !_isSending.value) {
                _requestListen.emit(Unit)
            }
        }
    }

    fun regenerateLast() {
        val lastUser = _messages.value.lastOrNull { it.role == MessageRole.USER } ?: return
        _messages.value = _messages.value.dropLastWhile { it.role == MessageRole.ASSISTANT }
        _messages.value = _messages.value.dropLastWhile { it.role == MessageRole.USER }
        _inputText.value = lastUser.content.let {
            if (it == "[Image attached]") "" else it
        }
        if (lastUser.imageUri != null) {
            try {
                _pendingImageUri.value = Uri.parse(lastUser.imageUri)
            } catch (_: Exception) {
            }
        }
        sendMessage()
    }

    fun cancelStreaming() {
        streamJob?.cancel()
        streamJob = null
        _isSending.value = false
        _messages.value = _messages.value.map {
            if (it.isStreaming) it.copy(isStreaming = false) else it
        }
    }

    private fun buildApiHistory(
        excludeId: String,
        currentText: String,
        currentImageDataUrl: String?
    ): List<ApiChatMessage> {
        val past = _messages.value
            .filter { it.id != excludeId && it.content.isNotBlank() && it.role != MessageRole.SYSTEM }
            .dropLastWhile { it.role == MessageRole.USER }
            .takeLast(30)
            .map {
                ApiChatMessage(
                    role = when (it.role) {
                        MessageRole.USER -> "user"
                        MessageRole.ASSISTANT -> "assistant"
                        MessageRole.SYSTEM -> "system"
                    },
                    content = it.content
                )
            }

        val currentContent: Any = if (currentImageDataUrl != null) {
            val parts = mutableListOf<ContentPart>()
            if (currentText.isNotBlank()) {
                parts.add(ContentPart(type = "text", text = currentText))
            } else {
                parts.add(ContentPart(type = "text", text = "Describe and analyze this image."))
            }
            parts.add(ContentPart(type = "image", image = currentImageDataUrl))
            parts
        } else {
            currentText.ifBlank { "Hello" }
        }

        return past + ApiChatMessage(role = "user", content = currentContent)
    }

    private fun updateAssistant(id: String, message: ChatMessage) {
        _messages.value = _messages.value.map { if (it.id == id) message else it }
    }

    private fun isBackendConfigured(): Boolean {
        val url = ApiConfig.BASE_URL
        val secret = ApiConfig.API_SECRET
        return url.isNotBlank() &&
            !url.contains("YOUR_VERCEL_PROJECT") &&
            secret.isNotBlank() &&
            secret != "change-me-to-match-server-secret"
    }
}
