package com.nova.ai.data.db

import com.nova.ai.data.model.ChatMessage
import com.nova.ai.data.model.Conversation
import com.nova.ai.data.model.MessageRole

fun ConversationEntity.toDomain(messages: List<ChatMessage> = emptyList()) = Conversation(
    id = id,
    title = title,
    messages = messages,
    createdAt = createdAt,
    updatedAt = updatedAt,
    preview = preview
)

fun Conversation.toEntity() = ConversationEntity(
    id = id,
    title = title,
    preview = preview,
    createdAt = createdAt,
    updatedAt = updatedAt
)

fun MessageEntity.toDomain() = ChatMessage(
    id = id,
    role = when (role.uppercase()) {
        "USER" -> MessageRole.USER
        "ASSISTANT" -> MessageRole.ASSISTANT
        else -> MessageRole.SYSTEM
    },
    content = content,
    timestamp = timestamp,
    imageUri = imageUri,
    isStreaming = false,
    isError = isError
)

fun ChatMessage.toEntity(conversationId: String) = MessageEntity(
    id = id,
    conversationId = conversationId,
    role = role.name,
    content = content,
    timestamp = timestamp,
    imageUri = imageUri,
    isError = isError
)

data class MemoryItem(
    val id: String,
    val key: String,
    val value: String,
    val createdAt: Long,
    val updatedAt: Long
)

fun MemoryItemEntity.toDomain() = MemoryItem(
    id = id,
    key = key,
    value = value,
    createdAt = createdAt,
    updatedAt = updatedAt
)

fun MemoryItem.toEntity() = MemoryItemEntity(
    id = id,
    key = key,
    value = value,
    createdAt = createdAt,
    updatedAt = updatedAt
)
