# NOVA AI – Secure Vercel Backend (Stage 2)

Server-side API for the NOVA AI Android app.  
**All AI credentials stay here. The Android app never sees them.**

---

## Endpoints

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `GET` | `/api/health` | No | Health + provider status |
| `GET` | `/api/models` | Yes | Allowed models |
| `POST` | `/api/chat` | Yes | Streaming (or non-streaming) chat |
| `OPTIONS` | all above | No | CORS preflight |

---

## Security features

- **Bearer auth** via `Authorization: Bearer <NOVA_API_SECRET>`
- **Client ID** via `X-Client-Id` (used for rate limiting)
- **Request validation** with Zod (message count, length, model allow-list)
- **Rate limiting** (configurable, per client)
- **CORS** headers for mobile clients
- **No keys in client** – Android only knows the backend URL + shared secret
- **Error sanitization** – upstream provider errors are not leaked raw

---

## Quick start (local)

```bash
cd backend
cp .env.example .env.local
# Edit .env.local – set at least OPENAI_API_KEY and NOVA_API_SECRET

npm install
npm run dev
```

Server runs at `http://localhost:3000`.

### Test health

```bash
curl http://localhost:3000/api/health
```

### Test chat (streaming)

```bash
curl -N -X POST http://localhost:3000/api/chat \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_SECRET" \
  -H "X-Client-Id: test-device-1" \
  -d '{
    "messages": [{"role": "user", "content": "Hello NOVA"}],
    "stream": true
  }'
```

---

## Deploy to Vercel

1. Install Vercel CLI: `npm i -g vercel`
2. From `backend/`:
   ```bash
   vercel
   ```
3. In the Vercel Dashboard → Project → Settings → Environment Variables, add:
   - `OPENAI_API_KEY` (or `AI_GATEWAY_API_KEY`)
   - `NOVA_API_SECRET` (long random string)
   - Optional: `DEFAULT_MODEL`, `ALLOWED_MODELS`, rate-limit vars
4. Redeploy if needed: `vercel --prod`

After deploy you get a URL like:
`https://nova-ai-backend-xxxx.vercel.app`

Use that as `BASE_URL` in the Android app (Stage 3).

---

## Request format (`POST /api/chat`)

```json
{
  "messages": [
    { "role": "user", "content": "Explain coroutines in Kotlin" }
  ],
  "model": "gpt-4o-mini",
  "temperature": 0.7,
  "maxTokens": 2048,
  "stream": true
}
```

**Streaming response:** AI SDK data stream (text deltas).  
**Non-streaming:** JSON `{ id, model, content, usage }`.

---

## Android client contract (for Stage 3)

```
POST {BASE_URL}/api/chat
Headers:
  Content-Type: application/json
  Authorization: Bearer {NOVA_API_SECRET}
  X-Client-Id: {install-or-device-uuid}
Body: ChatRequest (see above)
```

Store `NOVA_API_SECRET` and `BASE_URL` in Android using **BuildConfig** or encrypted preferences — never hardcode the OpenAI key.

---

## Rate limits

Default: **30 requests / 60 seconds** per `X-Client-Id`.  
Tune with `RATE_LIMIT_MAX` and `RATE_LIMIT_WINDOW_SEC`.

For production-grade global limits, swap the in-memory limiter for Upstash Redis / Vercel KV.

---

## Stage roadmap

| Stage | Status |
|-------|--------|
| 1 – Android UI | Done |
| **2 – Vercel backend** | **Done** |
| 3 – Connect real AI from Android | Next |
| 4 – Persistent history + memory | Pending |
| 5 – Images + web research | Pending |
| 6 – Voice | Pending |
| 7 – Release | Pending |
