/**
 * Central configuration – reads only from server-side environment.
 * Never import this into client components.
 */

function required(name: string, fallback?: string): string {
  const value = process.env[name] ?? fallback;
  if (!value) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
}

function optional(name: string, fallback = ""): string {
  return process.env[name] ?? fallback;
}

function number(name: string, fallback: number): number {
  const raw = process.env[name];
  if (!raw) return fallback;
  const n = Number(raw);
  return Number.isFinite(n) ? n : fallback;
}

export const config = {
  // Auth
  apiSecret: optional("NOVA_API_SECRET", ""),

  // Provider
  openaiApiKey: optional("OPENAI_API_KEY"),
  openaiBaseUrl: optional("OPENAI_BASE_URL") || undefined,
  aiGatewayKey: optional("AI_GATEWAY_API_KEY"),
  aiGatewayBaseUrl: optional("AI_GATEWAY_BASE_URL", "https://gateway.ai.vercel.sh/v1"),

  // Models
  defaultModel: optional("DEFAULT_MODEL", "gpt-4o-mini"),
  allowedModels: optional(
    "ALLOWED_MODELS",
    "gpt-4o-mini,gpt-4o,gpt-4.1-mini,gpt-4.1"
  )
    .split(",")
    .map((m) => m.trim())
    .filter(Boolean),

  // Rate limit
  rateLimitMax: number("RATE_LIMIT_MAX", 30),
  rateLimitWindowSec: number("RATE_LIMIT_WINDOW_SEC", 60),

  // Misc
  isDev: process.env.NODE_ENV === "development",
} as const;

export function hasProviderConfigured(): boolean {
  return Boolean(config.openaiApiKey || config.aiGatewayKey);
}
