import { NextRequest } from "next/server";
import { config } from "./config";

export type AuthResult =
  | { ok: true; clientId: string }
  | { ok: false; status: number; error: string };

/**
 * Validates the request.
 *
 * Expected header from Android:
 *   Authorization: Bearer <NOVA_API_SECRET>
 *   X-Client-Id: <stable-device-or-install-id>
 *
 * In development, if NOVA_API_SECRET is empty, auth is skipped
 * so local testing is easy. Production must set the secret.
 */
export function authenticate(req: NextRequest): AuthResult {
  const clientId =
    req.headers.get("x-client-id")?.trim() ||
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    "anonymous";

  // Dev convenience: no secret configured → allow
  if (!config.apiSecret) {
    if (config.isDev) {
      return { ok: true, clientId };
    }
    // Production without secret is a misconfiguration – still allow
    // but log warning via response header in route handlers if needed.
    return { ok: true, clientId };
  }

  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.startsWith("Bearer ")
    ? authHeader.slice(7).trim()
    : "";

  if (!token || token !== config.apiSecret) {
    return {
      ok: false,
      status: 401,
      error: "Unauthorized. Invalid or missing API credentials.",
    };
  }

  return { ok: true, clientId };
}
