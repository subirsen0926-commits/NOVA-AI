import { z } from "zod";
import { config } from "./config";

/** Text-only or multimodal content parts */
export const ContentPartSchema = z.union([
  z.object({
    type: z.literal("text"),
    text: z.string().min(1).max(32_000),
  }),
  z.object({
    type: z.literal("image"),
    /** data URL or https URL */
    image: z.string().min(1).max(5_000_000),
  }),
]);

export const ChatMessageSchema = z.object({
  role: z.enum(["user", "assistant", "system"]),
  /** Plain string (backward compatible) or array of content parts */
  content: z.union([
    z.string().min(1).max(32_000),
    z.array(ContentPartSchema).min(1).max(10),
  ]),
});

export const ChatRequestSchema = z.object({
  messages: z
    .array(ChatMessageSchema)
    .min(1, "At least one message is required")
    .max(50, "Too many messages in context"),
  model: z.string().optional(),
  temperature: z.number().min(0).max(2).optional().default(0.7),
  maxTokens: z.number().int().min(64).max(8192).optional().default(2048),
  stream: z.boolean().optional().default(true),
  system: z.string().max(8000).optional(),
  /** When true, backend runs web search on the last user text and injects results */
  enableWebSearch: z.boolean().optional().default(false),
  /** Optional explicit search query (defaults to last user message text) */
  searchQuery: z.string().max(500).optional(),
});

export type ChatRequest = z.infer<typeof ChatRequestSchema>;

export const ResearchRequestSchema = z.object({
  query: z.string().min(1).max(500),
  maxResults: z.number().int().min(1).max(10).optional().default(5),
  /** If true, also summarize with the LLM */
  summarize: z.boolean().optional().default(true),
});

export type ResearchRequest = z.infer<typeof ResearchRequestSchema>;

export function resolveModel(requested?: string): string {
  const model = (requested || config.defaultModel).trim();
  if (!config.allowedModels.includes(model)) {
    return config.defaultModel;
  }
  return model;
}

/** Prefer a vision-capable model when images are present */
export function resolveModelForMessages(
  requested: string | undefined,
  hasImages: boolean
): string {
  if (hasImages) {
    const visionPreferred = ["gpt-4o", "gpt-4.1", "gpt-4o-mini", "gpt-4.1-mini"];
    for (const m of visionPreferred) {
      if (config.allowedModels.includes(m)) {
        if (!requested || requested === config.defaultModel) return m;
      }
    }
  }
  return resolveModel(requested);
}
