/**
 * Web search integration for NOVA AI.
 * Supports Tavily (preferred) or Serper. Keys stay server-side only.
 */

import { config } from "./config";

export interface SearchResult {
  title: string;
  url: string;
  snippet: string;
}

export interface SearchResponse {
  query: string;
  results: SearchResult[];
  provider: string;
}

function getTavilyKey(): string | undefined {
  return process.env.TAVILY_API_KEY || undefined;
}

function getSerperKey(): string | undefined {
  return process.env.SERPER_API_KEY || undefined;
}

export function isSearchConfigured(): boolean {
  return Boolean(getTavilyKey() || getSerperKey());
}

export async function webSearch(
  query: string,
  maxResults = 5
): Promise<SearchResponse> {
  const tavily = getTavilyKey();
  if (tavily) {
    return searchTavily(query, maxResults, tavily);
  }
  const serper = getSerperKey();
  if (serper) {
    return searchSerper(query, maxResults, serper);
  }
  throw new Error(
    "Web search is not configured. Set TAVILY_API_KEY or SERPER_API_KEY on the server."
  );
}

async function searchTavily(
  query: string,
  maxResults: number,
  apiKey: string
): Promise<SearchResponse> {
  const res = await fetch("https://api.tavily.com/search", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      api_key: apiKey,
      query,
      max_results: maxResults,
      include_answer: false,
      search_depth: "basic",
    }),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Tavily search failed (${res.status}): ${text.slice(0, 200)}`);
  }

  const data = (await res.json()) as {
    results?: Array<{ title?: string; url?: string; content?: string }>;
  };

  const results: SearchResult[] = (data.results || []).map((r) => ({
    title: r.title || "Untitled",
    url: r.url || "",
    snippet: r.content || "",
  }));

  return { query, results, provider: "tavily" };
}

async function searchSerper(
  query: string,
  maxResults: number,
  apiKey: string
): Promise<SearchResponse> {
  const res = await fetch("https://google.serper.dev/search", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-API-KEY": apiKey,
    },
    body: JSON.stringify({ q: query, num: maxResults }),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Serper search failed (${res.status}): ${text.slice(0, 200)}`);
  }

  const data = (await res.json()) as {
    organic?: Array<{ title?: string; link?: string; snippet?: string }>;
  };

  const results: SearchResult[] = (data.organic || []).slice(0, maxResults).map((r) => ({
    title: r.title || "Untitled",
    url: r.link || "",
    snippet: r.snippet || "",
  }));

  return { query, results, provider: "serper" };
}

/**
 * Formats search results into a context block for the model.
 */
export function formatSearchContext(search: SearchResponse): string {
  if (search.results.length === 0) {
    return `Web search for "${search.query}" returned no results.`;
  }

  const lines = search.results.map(
    (r, i) =>
      `[${i + 1}] ${r.title}\nURL: ${r.url}\n${r.snippet}`
  );

  return [
    `Web search results for: "${search.query}" (provider: ${search.provider})`,
    "Use these sources. Cite them with [n] and include URLs when stating facts.",
    "Clearly distinguish verified information from uncertainty or speculation.",
    "",
    ...lines,
  ].join("\n");
}
