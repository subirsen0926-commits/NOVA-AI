import { config } from "./config";

/**
 * Simple sliding-window rate limiter.
 *
 * NOTE: In serverless, each instance has its own memory.
 * For strong global limits in production, replace with
 * Upstash Redis or Vercel KV. This still protects against
 * accidental floods from a single client on one instance.
 */

interface Bucket {
  timestamps: number[];
}

const buckets = new Map<string, Bucket>();

function prune(bucket: Bucket, windowMs: number, now: number) {
  const cutoff = now - windowMs;
  bucket.timestamps = bucket.timestamps.filter((t) => t > cutoff);
}

export type RateLimitResult =
  | { allowed: true; remaining: number; resetSec: number }
  | { allowed: false; remaining: 0; resetSec: number; retryAfterSec: number };

export function checkRateLimit(clientId: string): RateLimitResult {
  const windowMs = config.rateLimitWindowSec * 1000;
  const max = config.rateLimitMax;
  const now = Date.now();

  let bucket = buckets.get(clientId);
  if (!bucket) {
    bucket = { timestamps: [] };
    buckets.set(clientId, bucket);
  }

  prune(bucket, windowMs, now);

  if (bucket.timestamps.length >= max) {
    const oldest = bucket.timestamps[0] ?? now;
    const retryAfterSec = Math.ceil((oldest + windowMs - now) / 1000);
    return {
      allowed: false,
      remaining: 0,
      resetSec: config.rateLimitWindowSec,
      retryAfterSec: Math.max(1, retryAfterSec),
    };
  }

  bucket.timestamps.push(now);
  return {
    allowed: true,
    remaining: max - bucket.timestamps.length,
    resetSec: config.rateLimitWindowSec,
  };
}

/** Periodic cleanup to avoid unbounded growth in long-lived instances */
setInterval(() => {
  const now = Date.now();
  const windowMs = config.rateLimitWindowSec * 1000;
  for (const [key, bucket] of buckets.entries()) {
    prune(bucket, windowMs, now);
    if (bucket.timestamps.length === 0) {
      buckets.delete(key);
    }
  }
}, 60_000).unref?.();
