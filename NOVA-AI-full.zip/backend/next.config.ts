import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Ensure API routes run on Edge where possible for low latency streaming
  experimental: {
    // Keep default; AI SDK streaming works on both Node and Edge
  },
  // Headers for security
  async headers() {
    return [
      {
        source: "/api/:path*",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "X-Frame-Options", value: "DENY" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
        ],
      },
    ];
  },
};

export default nextConfig;
