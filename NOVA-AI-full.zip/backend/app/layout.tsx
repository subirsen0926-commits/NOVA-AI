import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "NOVA AI Backend",
  description: "Secure backend for NOVA AI Android assistant",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body style={{ margin: 0, background: "#0a0b14" }}>{children}</body>
    </html>
  );
}
