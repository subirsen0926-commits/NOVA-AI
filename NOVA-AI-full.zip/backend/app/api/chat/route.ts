import { streamText, generateText, CoreMessage } from "ai";
import { NextRequest } from "next/server";
import { authenticate } from "@/lib/auth";
import { getProvider, SYSTEM_PROMPT } from "@/lib/ai";
import { hasProviderConfigured } from "@/lib/config";
import { corsHeaders, handleOptions, jsonError, withCors } from "@/lib/cors";
import { checkRateLimit } from "@/lib/rate-limit";
import {
  ChatRequestSchema,
  resolveModelForMessages,
} from "@/lib/schemas";
import {
  formatSearchContext,
  isSearchConfigured,
  webSearch,
} from "@/lib/search";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function OPTIONS() {
  return handleOptions();
}

type ContentPart =
  | { type: "text"; text: string }
  | { type: "image"; image: string };

function extractText(content: string | ContentPart[]): string {
  if (typeof content === "string") return content;
  return content
    .filter((p): p is { type: "text"; text: string } => p.type === "text")
    .map((p) => p.text)
    .join("\n");
}

function hasImagesInMessages(
  messages: Array<{ content: string | ContentPart[] }>
): boolean {
  return messages.some((m) => {
    if (typeof m.content === "string") return false;
    return m.content.some((p) => p.type === "image");
  });
}

/** Convert our schema messages to AI SDK CoreMessage format */
function toCoreMessages(
  messages: Array<{ role: string; content: string | ContentPart[] }>
): CoreMessage[] {
  return messages.map((m) => {
    const role = m.role as "user" | "assistant" | "system";
    if (typeof m.content === "string") {
      return { role, content: m.content } as CoreMessage;
    }
    // Multimodal user message
    const parts = m.content.map((p) => {
      if (p.type === "text") {
        return { type: "text" as const, text: p.text };
      }
      // image – AI SDK expects image as URL or data URL in `image` field
      return {
        type: "image" as const,
        image: p.image,
      };
    });
    return { role, content: parts } as CoreMessage;
  });
}

export async function POST(req: NextRequest) {
  try {
    const auth = authenticate(req);
    if (!auth.ok) {
      return jsonError(auth.status, auth.error);
    }

    const rl = checkRateLimit(auth.clientId);
    if (!rl.allowed) {
      return jsonError(429, "Rate limit exceeded. Please slow down.", {
        retryAfterSec: rl.retryAfterSec,
      });
    }

    if (!hasProviderConfigured()) {
      return jsonError(
        503,
        "AI provider is not configured on the server. Set OPENAI_API_KEY or AI_GATEWAY_API_KEY."
      );
    }

    let body: unknown;
    try {
      body = await req.json();
    } catch {
      return jsonError(400, "Invalid JSON body");
    }

    const parsed = ChatRequestSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(400, "Validation failed", {
        details: parsed.error.flatten(),
      });
    }

    const data = parsed.data;
    const hasImages = hasImagesInMessages(data.messages);
    const modelId = resolveModelForMessages(data.model, hasImages);
    const provider = getProvider();

    // --- Optional web search injection ---
    let searchBlock = "";
    if (data.enableWebSearch) {
      if (!isSearchConfigured()) {
        return jsonError(
          503,
          "Web search is not configured. Set TAVILY_API_KEY or SERPER_API_KEY on the server."
        );
      }
      const lastUser = [...data.messages].reverse().find((m) => m.role === "user");
      const query =
        data.searchQuery?.trim() ||
        (lastUser ? extractText(lastUser.content as string | ContentPart[]) : "");
      if (query) {
        try {
          const search = await webSearch(query, 5);
          searchBlock = formatSearchContext(search);
        } catch (e) {
          const msg = e instanceof Error ? e.message : "Search failed";
          return jsonError(502, msg);
        }
      }
    }

    let systemContent = data.system
      ? `${SYSTEM_PROMPT}\n\nAdditional instructions:\n${data.system}`
      : SYSTEM_PROMPT;

    if (searchBlock) {
      systemContent += `\n\n${searchBlock}`;
    }

    if (hasImages) {
      systemContent +=
        "\n\nThe user may attach images. Describe and analyze them accurately. If unsure about something in an image, say so.";
    }

    const coreMessages = toCoreMessages(data.messages);
    const messages: CoreMessage[] = [
      { role: "system", content: systemContent },
      ...coreMessages,
    ];

    const common = {
      model: provider(modelId),
      messages,
      temperature: data.temperature,
      maxTokens: data.maxTokens,
    };

    const url = new URL(req.url);
    const formatParam = url.searchParams.get("format");
    const accept = req.headers.get("accept") || "";
    const preferTextStream =
      formatParam === "text" || accept.includes("text/plain");

    if (data.stream !== false) {
      const result = streamText(common);

      if (preferTextStream) {
        const stream = new ReadableStream({
          async start(controller) {
            const encoder = new TextEncoder();
            try {
              for await (const delta of result.textStream) {
                controller.enqueue(encoder.encode(delta));
              }
              controller.close();
            } catch (e) {
              controller.error(e);
            }
          },
        });

        return new Response(stream, {
          status: 200,
          headers: {
            "Content-Type": "text/plain; charset=utf-8",
            "Cache-Control": "no-cache, no-transform",
            "X-Accel-Buffering": "no",
            "X-RateLimit-Remaining": String(rl.remaining),
            "X-RateLimit-Reset": String(rl.resetSec),
            "X-Model": modelId,
            "X-Web-Search": data.enableWebSearch ? "1" : "0",
            ...corsHeaders(),
          },
        });
      }

      const response = result.toDataStreamResponse({
        headers: {
          ...corsHeaders(),
          "X-RateLimit-Remaining": String(rl.remaining),
          "X-RateLimit-Reset": String(rl.resetSec),
          "X-Model": modelId,
        },
      });

      return withCors(response);
    }

    const result = await generateText(common);

    return new Response(
      JSON.stringify({
        id: crypto.randomUUID(),
        model: modelId,
        content: result.text,
        usage: result.usage,
        webSearch: data.enableWebSearch || false,
      }),
      {
        status: 200,
        headers: {
          "Content-Type": "application/json",
          ...corsHeaders(),
          "X-RateLimit-Remaining": String(rl.remaining),
          "X-Model": modelId,
        },
      }
    );
  } catch (err) {
    console.error("[NOVA /api/chat]", err);
    const message =
      err instanceof Error ? err.message : "Internal server error";

    const safe =
      message.includes("API key") || message.includes("Unauthorized")
        ? "Upstream AI provider rejected the request. Check server configuration."
        : message.includes("timeout") || message.includes("Timeout")
          ? "The AI provider timed out. Please try again."
          : "Something went wrong while generating a response.";

    return jsonError(500, safe);
  }
}
