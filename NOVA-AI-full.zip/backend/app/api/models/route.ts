import { NextRequest } from "next/server";
import { authenticate } from "@/lib/auth";
import { config } from "@/lib/config";
import { corsHeaders, handleOptions, jsonError } from "@/lib/cors";

export const runtime = "edge";

export async function OPTIONS() {
  return handleOptions();
}

export async function GET(req: NextRequest) {
  const auth = authenticate(req);
  if (!auth.ok) {
    return jsonError(auth.status, auth.error);
  }

  return new Response(
    JSON.stringify({
      default: config.defaultModel,
      models: config.allowedModels.map((id) => ({
        id,
        label: id,
      })),
    }),
    {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders(),
      },
    }
  );
}
