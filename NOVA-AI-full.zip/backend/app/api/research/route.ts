import { generateText } from "ai";
import { NextRequest } from "next/server";
import { authenticate } from "@/lib/auth";
import { getProvider, SYSTEM_PROMPT } from "@/lib/ai";
import { hasProviderConfigured } from "@/lib/config";
import { corsHeaders, handleOptions, jsonError } from "@/lib/cors";
import { checkRateLimit } from "@/lib/rate-limit";
import { ResearchRequestSchema, resolveModel } from "@/lib/schemas";
import {
  formatSearchContext,
  isSearchConfigured,
  webSearch,
} from "@/lib/search";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function OPTIONS() {
  return handleOptions();
}

export async function POST(req: NextRequest) {
  try {
    const auth = authenticate(req);
    if (!auth.ok) {
      return jsonError(auth.status, auth.error);
    }

    const rl = checkRateLimit(auth.clientId);
    if (!rl.allowed) {
      return jsonError(429, "Rate limit exceeded. Please slow down.", {
        retryAfterSec: rl.retryAfterSec,
      });
    }

    if (!isSearchConfigured()) {
      return jsonError(
        503,
        "Web search is not configured. Set TAVILY_API_KEY or SERPER_API_KEY on the server."
      );
    }

    let body: unknown;
    try {
      body = await req.json();
    } catch {
      return jsonError(400, "Invalid JSON body");
    }

    const parsed = ResearchRequestSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(400, "Validation failed", {
        details: parsed.error.flatten(),
      });
    }

    const { query, maxResults, summarize } = parsed.data;
    const search = await webSearch(query, maxResults);

    let summary: string | null = null;
    if (summarize && hasProviderConfigured()) {
      try {
        const provider = getProvider();
        const modelId = resolveModel();
        const context = formatSearchContext(search);
        const result = await generateText({
          model: provider(modelId),
          messages: [
            {
              role: "system",
              content: `${SYSTEM_PROMPT}

You are in research mode. Summarize the web search results below.
Rules:
- Cite sources with [n] and include the URL after each key claim when possible.
- Distinguish verified facts from uncertainty.
- Be concise and structured (short paragraphs or bullets).
- Do not invent sources that were not in the results.`,
            },
            {
              role: "user",
              content: `Research query: ${query}\n\n${context}\n\nProvide a clear research summary with sources.`,
            },
          ],
          temperature: 0.3,
          maxTokens: 1500,
        });
        summary = result.text;
      } catch (e) {
        console.error("[NOVA /api/research] summarize failed", e);
        summary = null;
      }
    }

    return new Response(
      JSON.stringify({
        query: search.query,
        provider: search.provider,
        results: search.results,
        summary,
      }),
      {
        status: 200,
        headers: {
          "Content-Type": "application/json",
          ...corsHeaders(),
          "X-RateLimit-Remaining": String(rl.remaining),
        },
      }
    );
  } catch (err) {
    console.error("[NOVA /api/research]", err);
    const message =
      err instanceof Error ? err.message : "Research request failed";
    return jsonError(500, message);
  }
}
EOF
