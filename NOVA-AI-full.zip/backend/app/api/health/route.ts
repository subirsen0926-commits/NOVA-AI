import { NextResponse } from "next/server";
import { hasProviderConfigured, config } from "@/lib/config";
import { corsHeaders, handleOptions } from "@/lib/cors";
import { isSearchConfigured } from "@/lib/search";

export const runtime = "nodejs";

export async function OPTIONS() {
  return handleOptions();
}

export async function GET() {
  return NextResponse.json(
    {
      status: "ok",
      service: "NOVA AI Backend",
      version: "1.1.0",
      providerConfigured: hasProviderConfigured(),
      searchConfigured: isSearchConfigured(),
      defaultModel: config.defaultModel,
      timestamp: new Date().toISOString(),
    },
    { headers: corsHeaders() }
  );
}
