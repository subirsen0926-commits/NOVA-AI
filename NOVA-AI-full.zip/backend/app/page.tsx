export default function Home() {
  return (
    <main
      style={{
        fontFamily: "system-ui, sans-serif",
        maxWidth: 640,
        margin: "4rem auto",
        padding: "0 1.5rem",
        color: "#e8eaff",
        background: "#0a0b14",
        minHeight: "100vh",
      }}
    >
      <h1 style={{ fontSize: "2rem", marginBottom: "0.5rem" }}>NOVA AI Backend</h1>
      <p style={{ color: "#a0a4c0", marginBottom: "2rem" }}>
        Secure API for the NOVA AI Android assistant.
      </p>
      <ul style={{ lineHeight: 1.8, color: "#c8cbe0" }}>
        <li>
          <code>GET /api/health</code> — health check
        </li>
        <li>
          <code>GET /api/models</code> — allowed models
        </li>
        <li>
          <code>POST /api/chat</code> — streaming chat (auth required)
        </li>
      </ul>
      <p style={{ marginTop: "2rem", fontSize: "0.875rem", color: "#6b6f8c" }}>
        Credentials stay on the server. Never expose API keys in the mobile app.
      </p>
    </main>
  );
}
