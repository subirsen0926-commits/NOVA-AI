#!/usr/bin/env bash
# Build NOVA AI APK on a machine with Android SDK + JDK 17+
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

BASE_URL="${NOVA_BASE_URL:-http://10.0.2.2:3000}"
API_SECRET="${NOVA_API_SECRET:-change-me-to-match-server-secret}"
BUILD_TYPE="${1:-debug}"   # debug | release

if [[ -z "${ANDROID_HOME:-}${ANDROID_SDK_ROOT:-}" ]]; then
  echo "Set ANDROID_HOME to your Android SDK path."
  exit 1
fi

echo "Building NOVA AI ($BUILD_TYPE)"
echo "  BASE_URL=$BASE_URL"

if [[ "$BUILD_TYPE" == "release" ]]; then
  ./gradlew assembleRelease \
    -PNOVA_BASE_URL="$BASE_URL" \
    -PNOVA_API_SECRET="$API_SECRET" \
    --no-daemon
  APK="app/build/outputs/apk/release/app-release-unsigned.apk"
  # If signing is configured, the file may be app-release.apk
  if [[ -f app/build/outputs/apk/release/app-release.apk ]]; then
    APK="app/build/outputs/apk/release/app-release.apk"
  fi
else
  ./gradlew assembleDebug \
    -PNOVA_BASE_URL="$BASE_URL" \
    -PNOVA_API_SECRET="$API_SECRET" \
    --no-daemon
  APK="app/build/outputs/apk/debug/app-debug.apk"
fi

echo ""
echo "Done: $ROOT/$APK"
ls -lh "$APK"
echo ""
echo "Install: adb install -r $APK"
