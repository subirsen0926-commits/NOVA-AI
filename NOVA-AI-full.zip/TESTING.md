# NOVA AI – Testing Checklist (Stage 7)

Use this list before shipping a release build.

## Prerequisites

- [ ] Backend deployed or running locally (`npm run dev`)
- [ ] `OPENAI_API_KEY` (or Gateway) set on server
- [ ] `NOVA_API_SECRET` set on server
- [ ] Android `ApiConfig` / BuildConfig points at that backend + matching secret
- [ ] Optional: `TAVILY_API_KEY` or `SERPER_API_KEY` for web research

```bash
curl https://YOUR_HOST/api/health
# expect: providerConfigured true, searchConfigured true/false
```

---

## Core chat

- [ ] New chat opens empty state
- [ ] Send text message → streaming tokens appear
- [ ] Copy / Share / Regenerate work on assistant bubble
- [ ] Error banner shows for wrong secret / offline
- [ ] Scroll stays near latest message while streaming

## History (Room)

- [ ] After a chat, Home shows conversation title/preview
- [ ] Force-stop app → reopen → history still listed
- [ ] Open past chat → messages restored
- [ ] Delete one conversation from Home
- [ ] Settings → Clear all history → list empty after restart

## Memory & settings

- [ ] Dark theme toggle persists
- [ ] Language selection persists
- [ ] Add memory item → appears in list
- [ ] Delete memory item
- [ ] With memory ON, model can use saved preference in replies
- [ ] Memory OFF → preference not injected

## Images

- [ ] Attach image → preview shown
- [ ] Remove pending image
- [ ] Send image (+ optional caption) → vision response
- [ ] Image thumbnail appears on user message

## Web research

- [ ] Enable **Web research** chip
- [ ] Ask a current-events question → answer cites sources / URLs
- [ ] Without search API key → clear 503-style error

## Voice

- [ ] Mic permission prompt appears once
- [ ] Mic → partial text in input → final result
- [ ] **Speak responses** ON → assistant reply is spoken
- [ ] Tap mic while speaking stops TTS
- [ ] **Voice mode** ON → listen → send → speak → listen loop
- [ ] Voice mode OFF stops the loop

## Security / config

- [ ] Placeholder `BASE_URL` shows configuration error (does not crash)
- [ ] No OpenAI/Tavily keys in APK strings (`strings`, source, BuildConfig only has backend URL + app secret)
- [ ] Release build: OkHttp logs disabled

## Release build smoke

```bash
./gradlew assembleRelease \
  -PNOVA_BASE_URL=https://your-backend.vercel.app \
  -PNOVA_API_SECRET=your-secret
```

- [ ] APK installs on a physical device
- [ ] Cold start → Home → New Chat → one successful reply
- [ ] Rotate device (or fold) without crash on Chat screen

---

## Known limitations (document for users)

1. STT/TTS quality depends on the device language pack.
2. Web research requires a server-side Tavily or Serper key.
3. Vision needs a multimodal model in `ALLOWED_MODELS` (e.g. gpt-4o-mini).
4. In-memory rate limits are per Vercel instance (upgrade to Redis for strict global limits).
