# NOVA AI – Release Guide

## 1. Backend (production)

```bash
cd backend
# Set in Vercel Dashboard → Environment Variables:
#   OPENAI_API_KEY
#   NOVA_API_SECRET          (openssl rand -hex 32)
#   DEFAULT_MODEL=gpt-4o-mini
#   ALLOWED_MODELS=gpt-4o-mini,gpt-4o
#   TAVILY_API_KEY           (optional)
npx vercel --prod
```

Note the production URL, e.g. `https://nova-ai-xxx.vercel.app`.

## 2. Configure Android for release

**Option A – Gradle properties (recommended for CI)**

```bash
./gradlew assembleRelease \
  -PNOVA_BASE_URL=https://nova-ai-xxx.vercel.app \
  -PNOVA_API_SECRET=THE_SAME_SECRET_AS_SERVER
```

**Option B – Edit fallbacks in `ApiConfig.kt`**

Set `FALLBACK_BASE_URL` and `FALLBACK_API_SECRET` (only if not using `-P` flags).

## 3. Sign the APK / AAB

```bash
# Create a keystore once (store it safely, off git)
keytool -genkey -v -keystore nova-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias nova
```

In `app/build.gradle.kts`, uncomment `signingConfigs.create("release")` and the release `signingConfig` line, then set passwords via env:

```bash
export NOVA_STORE_PASSWORD=...
export NOVA_KEY_PASSWORD=...
export NOVA_KEY_ALIAS=nova
```

Place `nova-release.jks` under `app/` (and add `*.jks` to `.gitignore`).

## 4. Build

```bash
# APK
./gradlew assembleRelease

# App Bundle (Play Store)
./gradlew bundleRelease
```

Outputs:

- `app/build/outputs/apk/release/app-release.apk`
- `app/build/outputs/bundle/release/app-release.aab`

## 5. Install locally

```bash
adb install -r app/build/outputs/apk/release/app-release.apk
```

## 6. Play Store notes

- Target SDK 35, min SDK 26
- Declare mic / photos permissions with rationales in the store listing
- Privacy policy: chat history and memory stay on device; prompts go to your backend only
- Do not list third-party AI keys in the app privacy form as collected by the app

## 7. Version bumps

In `app/build.gradle.kts` → `defaultConfig`:

```kotlin
versionCode = 2        // integer, always increase
versionName = "1.0.1"  // user-visible
```

---

**Security checklist before publish**

- [ ] No `OPENAI_API_KEY` in the Android project
- [ ] `NOVA_API_SECRET` is long and random
- [ ] Vercel env vars set for Production
- [ ] Rate limits enabled
- [ ] Release minify enabled (already on)
